function y=display_blocks(mat,title_name)
    %mat=not(mat);
    [r,c] = size(mat);                           %# Get the matrix size
    imagesc([1:c]-0.5,[1:r]-0.5,mat);            %# Plot the image
%     colormap(summer);                              %# Use a gray colormap
    set(gca,'XTick',0:c,'YTick',0:r,'GridLineStyle','-','GridColor','Black','LineWidth',1.5,'XColor','w','YColor','w');
    axis xy;
    title(title_name,'Color','w');
    xlabel('Z Axis Coordinate of Robots');
    ylabel('X Axis Coordinate of Robots');
%     %set(gca,'XTick',[0:c+0.5],'YTick',[0:r+0.5],'GridLineStyle','--','XGrid','on','YGrid','on');
%     fig = gcf;
%     fig.Position = [600.4000 86.6000 761.6000 660];
    grid on;
end