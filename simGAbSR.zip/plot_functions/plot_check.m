x=[1 2 3 4]
y=[2 3 4 5]
yy=[6 7 8 9]
yyy=[10 9 5 4]

figure(1)
plot(x,y, 'k', 'linewidth', 2)
plot(x,yy, 'k', 'linewidth', 2)
plot(x,yyy, 'k+', 'linewidth', 2)
