function [target, robots_pos,robots_pos_center] = init_target_char(target,number_of_robots,targ_char)
    floor_size = target.Floor.children.geometry.size;
    fls=floor_size(1)*floor_size(3);
    if fls>=25 & number_of_robots==5
        if mod(fls,2)==0
           floor_matrix = reshape(1:fls,floor_size(1),floor_size(3));
            center = (fls/2);
            if strcmp(targ_char,'T')
                new_pos(1) = (center-(floor_size(1)+1));
                new_pos(2) = (center-1);
                new_pos(3) = (center+floor_size(1)-1);
                new_pos(4) = center;
                new_pos(5) = (center+1);
                robot_x_cor = ones(number_of_robots,1);
                robot_y_cor = ones(number_of_robots,1);
                robot_z_cor = ones(number_of_robots,1);
                for i=1:number_of_robots
                    [robot_x_cor(i), robot_z_cor(i)] = find(floor_matrix==new_pos(i));
                end
                robots_pos = [robot_x_cor, robot_y_cor, robot_z_cor];
                robots_pos_center = robots_pos-0.5;
                i=1;
                for i=1:number_of_robots
                    robot = vrnode(target,strcat('robot',num2str(i)),'Transform');
                    robot_shape = vrnode(robot,'children',strcat('RobotShape',num2str(i)),'Shape');
                    robot_Apper = vrnode(robot_shape,'appearance',strcat('RobotAppearance',num2str(i)),'Appearance');
                    % robot_Mat = vrnode(robot_Apper,'material',strcat('RobotMaterial',num2str(i)),'Material');
                    % robot_Mat.diffuseColor = [rand(1) rand(1) rand(1)]
                    robot_box_size = vrnode(robot_shape,'geometry',strcat('RobotBox',num2str(i)),'Box');
                    robot_box_size.size = [1 1 1];
                    robot.translation = [robots_pos_center(i,1) robots_pos_center(i,2) robots_pos_center(i,3)];
                    % robot.center = [robots_pos_center(1,1) 0.5 robots_pos_center(1,2)]
                    image_size = 50;
                    x=255*rand*ones(image_size);
                    a = insertText(x,[round(image_size*30/100) round(image_size*20/100)],i,'FontSize',18,'BoxColor','blue','BoxOpacity',1.0,'TextColor','yellow');
                    imwrite(a,strcat('images_robot_texture/robot',num2str(i),'_im.png'));
                    robot_texture = vrnode(robot_Apper,'texture',strcat('RobotTexture',num2str(i)),'PixelTexture');
                    robot_texture.image = imread(strcat('images_robot_texture/robot',num2str(i),'_im.png'));
                    robot_texture.repeatS = 'true';
                    robot_texture.repeatT = 'true';
                end
            else
                
            end 
        else
            floor_matrix = reshape(1:fls,floor_size(1),floor_size(3));
            center = (fls/2)+0.5;
            if strcmp(targ_char,'T')
                new_pos(1) = (center-(floor_size(1)+1));
                new_pos(2) = (center-1);
                new_pos(3) = (center+floor_size(1)-1);
                new_pos(4) = center;
                new_pos(5) = (center+1);
                robot_x_cor = ones(number_of_robots,1);
                robot_y_cor = ones(number_of_robots,1);
                robot_z_cor = ones(number_of_robots,1);
                for i=1:number_of_robots
                    [robot_x_cor(i), robot_z_cor(i)] = find(floor_matrix==new_pos(i));
                end
                robots_pos = [robot_x_cor, robot_y_cor, robot_z_cor];
                robots_pos_center = robots_pos-0.5;
                i=1;
                for i=1:number_of_robots
                    robot = vrnode(target,strcat('robot',num2str(i)),'Transform');
                    robot_shape = vrnode(robot,'children',strcat('RobotShape',num2str(i)),'Shape');
                    robot_Apper = vrnode(robot_shape,'appearance',strcat('RobotAppearance',num2str(i)),'Appearance');
                    % robot_Mat = vrnode(robot_Apper,'material',strcat('RobotMaterial',num2str(i)),'Material');
                    % robot_Mat.diffuseColor = [rand(1) rand(1) rand(1)]
                    robot_box_size = vrnode(robot_shape,'geometry',strcat('RobotBox',num2str(i)),'Box');
                    robot_box_size.size = [1 1 1];
                    robot.translation = [robots_pos_center(i,1) robots_pos_center(i,2) robots_pos_center(i,3)];
                    % robot.center = [robots_pos_center(1,1) 0.5 robots_pos_center(1,2)]
                    image_size = 50;
                    x=255*rand*ones(image_size);
                    a = insertText(x,[round(image_size*30/100) round(image_size*20/100)],i,'FontSize',18,'BoxColor','blue','BoxOpacity',1.0,'TextColor','yellow');
                    imwrite(a,strcat('images_robot_texture/robot',num2str(i),'_im.png'));
                    robot_texture = vrnode(robot_Apper,'texture',strcat('RobotTexture',num2str(i)),'PixelTexture');
                    robot_texture.image = imread(strcat('images_robot_texture/robot',num2str(i),'_im.png'));
                    robot_texture.repeatS = 'true';
                    robot_texture.repeatT = 'true';
                end
            else
                
            end 
        end
    else
        disp('Arena Size is small or number of robots is larger as required...');
    end
end
