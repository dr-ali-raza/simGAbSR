function robot_pos=get_robot_pos(mynw,robot_no)
    robot_pos = eval(strcat('mynw.robot',num2str(robot_no),'.translation'));
    robot_pos = robot_pos+0.5;
end

