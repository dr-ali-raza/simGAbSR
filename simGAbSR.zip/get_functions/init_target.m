function [target, robots_pos,robots_pos_center] = init_target(target,number_of_robots,placement_type)
    floor_size = target.Floor.children.geometry.size;
    if strcmp(placement_type,'target_placement')
            fls=floor_size(1)*floor_size(3);
            robot_positions_row = round(rand()*number_of_robots);
            % here we have positions for all floor blocks as numbers if numbers are in
            % transpose of floor we can take it to make x axis and z axis appropreate.
            floor_matrix = reshape(1:fls,floor_size(1),floor_size(3));
            if robot_positions_row==0
                robot_positions_row=1;
            end
            robot_positions(:,1) = floor_matrix(:,robot_positions_row);
            robot_positions(:,2) = 1;
            % to find out the position of these random placement of blocks we can use
            % find function as given
            i=1;
            robot_x_cor = ones(number_of_robots,1);
            robot_y_cor = robot_positions(1:number_of_robots,2:2);
            robot_z_cor = ones(number_of_robots,1);
            
            for i=1:number_of_robots
                [robot_x_cor(i), robot_z_cor(i)] = find(floor_matrix==robot_positions(i));
            end
            %eval(sprintf('robot_%d = [1]', i));
            robots_pos = [robot_x_cor, robot_y_cor, robot_z_cor];
            robots_pos_center = robots_pos-0.5;
            i=1;
            for i=1:number_of_robots
                robot = vrnode(target,strcat('robot',num2str(i)),'Transform');
                robot_shape = vrnode(robot,'children',strcat('RobotShape',num2str(i)),'Shape');
                robot_Apper = vrnode(robot_shape,'appearance',strcat('RobotAppearance',num2str(i)),'Appearance');
                % robot_Mat = vrnode(robot_Apper,'material',strcat('RobotMaterial',num2str(i)),'Material');
                % robot_Mat.diffuseColor = [rand(1) rand(1) rand(1)]
                robot_box_size = vrnode(robot_shape,'geometry',strcat('RobotBox',num2str(i)),'Box');
                robot_box_size.size = [1 1 1];
                robot.translation = [robots_pos_center(i,1) robots_pos_center(i,2) robots_pos_center(i,3)];
                % robot.center = [robots_pos_center(1,1) 0.5 robots_pos_center(1,2)]
                image_size = 50;
                x=255*rand*ones(image_size);
                a = insertText(x,[round(image_size*30/100) round(image_size*20/100)],i,'FontSize',18,'BoxColor','blue','BoxOpacity',1.0,'TextColor','yellow');
                imwrite(a,strcat('images_robot_texture/robot',num2str(i),'_im.png'));
                robot_texture = vrnode(robot_Apper,'texture',strcat('RobotTexture',num2str(i)),'PixelTexture');
                robot_texture.image = imread(strcat('images_robot_texture/robot',num2str(i),'_im.png'));
                robot_texture.repeatS = 'true';
                robot_texture.repeatT = 'true';
            end
    elseif strcmp(placement_type,'target_placement1')
        fls=floor_size(1)*floor_size(3);
            robot_positions_row = round(rand()*number_of_robots);
            % here we have positions for all floor blocks as numbers if numbers are in
            % transpose of floor we can take it to make x axis and z axis appropreate.
            floor_matrix = reshape(1:fls,floor_size(1),floor_size(3));
            if robot_positions_row==0
                robot_positions_row=1;
            end
            robot_positions(:,1) = floor_matrix(robot_positions_row,:);
            robot_positions(:,2) = 1;
            % to find out the position of these random placement of blocks we can use
            % find function as given
            i=1;
            robot_x_cor = ones(number_of_robots,1);
            robot_y_cor = robot_positions(1:number_of_robots,2:2);
            robot_z_cor = ones(number_of_robots,1);
            
            for i=1:number_of_robots
                [robot_x_cor(i), robot_z_cor(i)] = find(floor_matrix==robot_positions(i));
            end
            %eval(sprintf('robot_%d = [1]', i));
            robots_pos = [robot_x_cor, robot_y_cor, robot_z_cor];
            robots_pos_center = robots_pos-0.5;
            i=1;
            for i=1:number_of_robots
                robot = vrnode(target,strcat('robot',num2str(i)),'Transform');
                robot_shape = vrnode(robot,'children',strcat('RobotShape',num2str(i)),'Shape');
                robot_Apper = vrnode(robot_shape,'appearance',strcat('RobotAppearance',num2str(i)),'Appearance');
                % robot_Mat = vrnode(robot_Apper,'material',strcat('RobotMaterial',num2str(i)),'Material');
                % robot_Mat.diffuseColor = [rand(1) rand(1) rand(1)]
                robot_box_size = vrnode(robot_shape,'geometry',strcat('RobotBox',num2str(i)),'Box');
                robot_box_size.size = [1 1 1];
                robot.translation = [robots_pos_center(i,1) robots_pos_center(i,2) robots_pos_center(i,3)];
                % robot.center = [robots_pos_center(1,1) 0.5 robots_pos_center(1,2)]
                image_size = 50;
                x=255*rand*ones(image_size);
                a = insertText(x,[round(image_size*30/100) round(image_size*20/100)],i,'FontSize',18,'BoxColor','blue','BoxOpacity',1.0,'TextColor','yellow');
                imwrite(a,strcat('images_robot_texture/robot',num2str(i),'_im.png'));
                robot_texture = vrnode(robot_Apper,'texture',strcat('RobotTexture',num2str(i)),'PixelTexture');
                robot_texture.image = imread(strcat('images_robot_texture/robot',num2str(i),'_im.png'));
                robot_texture.repeatS = 'true';
                robot_texture.repeatT = 'true';
            end
    end
end
