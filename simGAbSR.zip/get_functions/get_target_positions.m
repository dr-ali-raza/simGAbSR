function [number_of_robots,robots_pos] = get_target_positions(floor_x,floor_y,tt)
    r = floor_x;
    c = floor_y;
    mat = zeros(r,c);
    imagesc([1:c]-0.5,[1:r]-0.5,mat);            %# Plot the image
    colormap(summer);                              %# Use a gray colormap
    set(gca,'XTick',0:c,'YTick',0:r,'GridLineStyle','-','GridColor','Black','LineWidth',1.5);
    axis xy;
    grid on;
    if tt == 1
        title('Getting Target Positions'); 
    elseif tt == 2
        title('Getting Initial Positions'); 
    end
    %%
    a=0;
    mat=mat';
    while ~a
        [y,x] = ginput(1);
        x = ceil(x);
        y = ceil(y);
        if (x<=0) || (y<=0)
            a=1;
        else
            if (x>r) || (y>c)
                a=1;
            else
                if mat(x,y)==1
                    mat(x,y)=0;
                else
                    mat(x,y)=1;
                end
                hold on;
                imagesc([1:c]-0.5,[1:r]-0.5,mat);            %# Plot the image
                colormap(summer);                              %# Use a gray colormap
            end
        end
    end
    floor_matrix = reshape(1:(r*c),r,c);
    matrix_check = find(mat==1)
    matrix_check = matrix_check';
    robot_x_cor = ones(length(matrix_check),1);
    robot_y_cor = ones(length(matrix_check),1);
    robot_z_cor = ones(length(matrix_check),1);
    for i=1:length(matrix_check)
        [robot_x_cor(i), robot_z_cor(i)] = find(floor_matrix==matrix_check(i));
    end
        % to find out the position of these random placement of blocks we can use
        % find function as given
        
        
        %eval(sprintf('robot_%d = [1]', i));
    robots_pos = [robot_x_cor, robot_y_cor, robot_z_cor];
    coo = size(robots_pos);
    number_of_robots = coo(1);
    %%
end