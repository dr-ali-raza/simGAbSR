function [obj_val, robots_pos_new] = generate_robot_positions(mynw,bin_string,robots_pos,robots_pos_targ,target_mat)
obj_val=0;
robot_no_to_move=1;

for i=1:2:length(bin_string)
    if ismember(robots_pos(robot_no_to_move,:),robots_pos_targ,'rows') % Checking membership for robots in target matrix
        
    else
        if bin_string(i)==0 && bin_string(i+1)==0 % Making changes in robots_pos based on bin_string row matrix
            sensor_v = get_sensor_x(mynw,robots_pos,robot_no_to_move,1);
            movement = movecode(sensor_v(1),sensor_v(2),sensor_v(3),sensor_v(4),sensor_v(5),sensor_v(6),sensor_v(7),sensor_v(8),sensor_v(9));
            if movement == 1 || movement == 2 || movement == 8
                size_floor=mynw.Floor.children.geometry.size;
                if robots_pos(robot_no_to_move,1)==size_floor(1)
                    movement=0;
                end
            else
                if movement==0 && sensor_v(9)==1
                    movement=3;
                else
                    movement =0;
                end
            end
            if movement==0
                
            else
                robots_pos(robot_no_to_move,:)=movement_to_new_positions(mynw,movement,robots_pos(robot_no_to_move,:),'x',robot_no_to_move,0);
            end
            
        elseif bin_string(i)==0 && bin_string(i+1)==1
            sensor_v = get_sensor_z(mynw,robots_pos,robot_no_to_move,-1);
            movement = movecode(sensor_v(1),sensor_v(2),sensor_v(3),sensor_v(4),sensor_v(5),sensor_v(6),sensor_v(7),sensor_v(8),sensor_v(9));
            if movement == 1 || movement == 2 || movement == 8
                if movement == 1
                    movement = 5;
                elseif movement == 2
                    movement = 4;
                elseif movement == 8
                    movement = 6;
                end
                
                if robots_pos(robot_no_to_move,3)==1
                    movement=0;
                end
            else
                if movement==0 && sensor_v(9)==1
                    movement=7;
                else
                    movement =0;
                end
            end
            if movement==0
                
            else
                robots_pos(robot_no_to_move,:)=movement_to_new_positions(mynw,movement,robots_pos(robot_no_to_move,:),'z',robot_no_to_move,0);
            end
            
        elseif bin_string(i)==1 && bin_string(i+1)==0
            sensor_v = get_sensor_x(mynw,robots_pos,robot_no_to_move,-1);
            movement = movecode(sensor_v(1),sensor_v(2),sensor_v(3),sensor_v(4),sensor_v(5),sensor_v(6),sensor_v(7),sensor_v(8),sensor_v(9));
            if movement == 1 || movement == 2 || movement == 8
                if movement == 1
                    movement = 5;
                elseif movement == 2
                    movement = 4;
                elseif movement == 8
                    movement = 6;
                end
                
                if robots_pos(robot_no_to_move,1)==1
                    movement=0;
                end
            else
                if movement==0 && sensor_v(9)==1
                    movement=7;
                else
                    movement =0;
                end
            end
            if movement==0
                
            else
                robots_pos(robot_no_to_move,:)=movement_to_new_positions(mynw,movement,robots_pos(robot_no_to_move,:),'x',robot_no_to_move,0);
            end
            
        elseif bin_string(i)==1 && bin_string(i+1)==1
            sensor_v = get_sensor_z(mynw,robots_pos,robot_no_to_move,1);
            movement = movecode(sensor_v(1),sensor_v(2),sensor_v(3),sensor_v(4),sensor_v(5),sensor_v(6),sensor_v(7),sensor_v(8),sensor_v(9));
            if movement == 1 || movement == 2 || movement == 8
                size_floor=mynw.Floor.children.geometry.size;
                if robots_pos(robot_no_to_move,3)==size_floor(3)
                    movement=0;
                end
            else
                if movement==0 && sensor_v(9)==1
                    movement=3;
                else
                    movement =0;
                end
            end
            if movement==0
                
            else
                robots_pos(robot_no_to_move,:)=movement_to_new_positions(mynw,movement,robots_pos(robot_no_to_move,:),'z',robot_no_to_move,0);
            end
            
        end
    end
    robot_no_to_move=robot_no_to_move+1;
end
    robots_pos_new = robots_pos;
    obj_val = objective_function(robots_pos_new,robots_pos_targ,target_mat);
end