function output = get_sensor_z(mynw,robots_pos, robot_number,dir)
    output = [0 0 0 0 0 0 0 0 0];
    robots_pos = robots_pos-0.5;
    s = size(robots_pos);
    n = s(1);
    for i=1:9
        switch i
            case 1
                eval(strcat('robt=mynw.robot',num2str(robot_number),'.translation;'));
                robt(3) = robt(3)+1;
                for j=1:n
                    if robt==robots_pos(j,:)
                        output(1) = 1;
                    end
                end
            case 2
                eval(strcat('robt=mynw.robot',num2str(robot_number),'.translation;'));
                robt(3) = robt(3)+1;
                robt(2) = robt(2)+1;
                for j=1:n
                    if robt==robots_pos(j,:)
                        output(2) = 1;
                    end
                end
            case 3
                eval(strcat('robt=mynw.robot',num2str(robot_number),'.translation;'));
                robt(2) = robt(2)+1;
                for j=1:n
                    if robt==robots_pos(j,:)
                        output(3) = 1;
                    end
                end
            case 4
                eval(strcat('robt=mynw.robot',num2str(robot_number),'.translation;'));
                robt(3) = robt(3)-1;
                robt(2) = robt(2)+1;
                for j=1:n
                    if robt==robots_pos(j,:)
                        output(4) = 1;
                    end
                end
            case 5
                eval(strcat('robt=mynw.robot',num2str(robot_number),'.translation;'));
                robt(3) = robt(3)-1;
                for j=1:n
                    if robt==robots_pos(j,:)
                        output(5) = 1;
                    end
                end
            case 6
                eval(strcat('robt=mynw.robot',num2str(robot_number),'.translation;'));
                robt(3) = robt(3)-1;
                if robt(2)+0.5==1
                    output(6)=1;
                else
                    robt(2) = robt(2)-1;
                    for j=1:n
                        if robt==robots_pos(j,:)
                            output(6) = 1;
                        end
                    end
                end
            case 7
                eval(strcat('robt=mynw.robot',num2str(robot_number),'.translation;'));
                if robt(2)+0.5==1
                    output(7)=1;
                else
                    robt(2) = robt(2)-1;
                    for j=1:n
                        if robt==robots_pos(j,:)
                            output(7) = 1;
                        end
                    end
                end
            case 8
                eval(strcat('robt=mynw.robot',num2str(robot_number),'.translation;'));
                robt(3) = robt(3)+1;
                if robt(2)+0.5==1
                    output(8)=1;
                else
                    robt(2) = robt(2)-1;
                    for j=1:n
                        if robt==robots_pos(j,:)
                            output(8) = 1;
                        end
                    end
                end
            case 9
                eval(strcat('robt=mynw.robot',num2str(robot_number),'.translation;'));
                if dir>0
                    robt(3) = robt(3)+1;
                    if robt(2)+0.5==1

                    else
                        robt(2) = robt(2)-1;
                        robt(3) = robt(3)+1;
                        for j=1:n
                            if robt==robots_pos(j,:)
                                output(9) = 1;
                            end
                        end
                    end 
                elseif dir<0
                    robt(3) = robt(3)-2;
                    if robt(2)+0.5>=1
                        if robt(2)+0.5>1
                            robt(2) = robt(2)-1;
                        end
                        for j=1:n
                            if robt==robots_pos(j,:)
                                output(9) = 1;
                            end
                        end
                    end 
                    sensor1=output(1);
                    sensor2=output(2);
                    sensor8=output(8);
                    output(1)=output(5);
                    output(2)=output(4);
                    output(8)=output(6);
                    output(5)=sensor1;
                    output(4)=sensor2;
                    output(6)=sensor8;
                end
        end
    end
end