function robots_pos = gen_2nd_parent(floor_size,number_of_robots)   
    fls=floor_size(1)*floor_size(3);
    robot_positions_column = randperm(fls);
    robots_1to10 = robot_positions_column(1:number_of_robots);
    robot_positions = robots_1to10';
    robot_positions(1,1) = 1;
    robot_positions(:,2) = 1;
    robot_positions_new = robot_positions;

    % here we have positions for all floor blocks as numbers if numbers are in
    % transpose of floor we can take it to make x axis and z axis appropreate.
    floor_matrix = reshape(1:fls,floor_size(1),floor_size(3));
    % to find out the position of these random placement of blocks we can use
    % find function as given
    i=1;
    robot_x_cor = ones(number_of_robots,1);
    robot_y_cor = robot_positions_new(:,2);
    robot_z_cor = ones(number_of_robots,1);

    for i=1:number_of_robots
        [robot_x_cor(i), robot_z_cor(i)] = find(floor_matrix==robot_positions(i));
    end
    %eval(sprintf('robot_%d = [1]', i));
    robots_pos = [robot_x_cor, robot_y_cor, robot_z_cor];
end