function array = check_allow_moves(mynw,robots_pos,robots_pos_targ,robot_no_to_move)
    array = cell(1,4);
    [notrg,axis] = size(robots_pos_targ);
    checked = sum(ismember(robots_pos_targ,robots_pos(robot_no_to_move,:),'rows'));
    if checked==1
       return; 
    end
    size_floor=mynw.Floor.children.geometry.size;    
    %=====================================================================
    dir=1;
    sensor_v = get_sensor_x(mynw,robots_pos,robot_no_to_move,dir);
    %Checking Direction and then using the respective fuzzy logic
    if dir>0
            x_axis = size_floor(1);
            eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
            if pos(1)==x_axis
                robots_pos = robots_pos;
                %disp('Robot cannot move...');
                movement = 0;
            else
                movement = movecode(sensor_v(1),sensor_v(2),sensor_v(3),sensor_v(4),sensor_v(5),sensor_v(6),sensor_v(7),sensor_v(8),sensor_v(9));
                if movement == 1 || movement == 2 || movement == 8
                    
                else
                    if movement==0 && sensor_v(9)==1
                       movement=3; 
                    else
                       movement =0;
                    end
                end
            end        
    end
    %=====================================================================
    array{1,1} = strcat(num2str(robot_no_to_move),',',num2str(movement),',+x');
    %=====================================================================
    dir=-1;
    sensor_v = get_sensor_x(mynw,robots_pos,robot_no_to_move,-1);
    %Checking Direction and then using the respective fuzzy logic
    if dir<0
        eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
        if pos(1)==1
            robots_pos = robots_pos;
            %disp('Robot cannot move...');
            movement = 0;
        else
            movement = movecode(sensor_v(1),sensor_v(2),sensor_v(3),sensor_v(4),sensor_v(5),sensor_v(6),sensor_v(7),sensor_v(8),sensor_v(9));
            if movement == 1 || movement == 2 || movement == 8
                if movement == 1
                    movement = 5;
                elseif movement == 2
                    movement = 4;
                elseif movement == 8
                    movement = 6;
                end
            else
                if movement==0 && sensor_v(9)==1
                    movement=7;
                else
                    movement =0;
                end
            end
        end
    end
    %=====================================================================
    array{1,2} = strcat(num2str(robot_no_to_move),',',num2str(movement),',-x');
    %=====================================================================
    dir=1;
    sensor_v = get_sensor_z(mynw,robots_pos,robot_no_to_move,1);
    %Checking Direction and then using the respective fuzzy logic
    if dir>0
        z_axis = size_floor(3);
        eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
        if pos(3)==z_axis
            robots_pos = robots_pos;
            %disp('Robot cannot move...');
            movement = 0;
        else
            movement = movecode(sensor_v(1),sensor_v(2),sensor_v(3),sensor_v(4),sensor_v(5),sensor_v(6),sensor_v(7),sensor_v(8),sensor_v(9));
            if movement == 1 || movement == 2 || movement == 8
                
            else
                if movement==0 && sensor_v(9)==1
                    movement=3;
                else
                    movement =0;
                end
            end
        end
        
    end
    %=====================================================================
    array{1,3} = strcat(num2str(robot_no_to_move),',',num2str(movement),',+z');
    %=====================================================================
    dir=-1;
    sensor_v = get_sensor_z(mynw,robots_pos,robot_no_to_move,-1);
    %Checking Direction and then using the respective fuzzy logic
    if dir<0
        eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
        if pos(3)==1
            robots_pos = robots_pos;
            %disp('Robot cannot move...');
            movement = 0;
        else
            movement = movecode(sensor_v(1),sensor_v(2),sensor_v(3),sensor_v(4),sensor_v(5),sensor_v(6),sensor_v(7),sensor_v(8),sensor_v(9));
            if movement == 1 || movement == 2 || movement == 8
                if movement == 1
                    movement = 5;
                elseif movement == 2
                    movement = 4;
                elseif movement == 8
                    movement = 6;
                end
            else
                if movement==0 && sensor_v(9)==1
                    movement=7;
                else
                    movement =0;
                end
            end
        end
        
    end
    %=====================================================================
    array{1,4} = strcat(num2str(robot_no_to_move),',',num2str(movement),',-z');
    %=====================================================================
end