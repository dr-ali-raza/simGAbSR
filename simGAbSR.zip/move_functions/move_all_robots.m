% #Move all robots at the same time....
%====================================================
function [robots_pos] = move_all_robots(mynw,to_achive,robots_pos)
%====================================================
%%
movement=0;
total_robots = length(to_achive);
steps=60;
for i=1:steps
   for j=1:total_robots 
      movement=0;
      %%
      vl = to_achive{1,j};
      C = strsplit(vl,',');
      robot_no_to_move = str2double(C{1});
      movement = str2double(C{2});
      dirc = C{3};
      %%
      switch movement
          case 1
              %%
              if i==1
                  eval(strcat('last_robot_trans',num2str(robot_no_to_move),' = mynw.robot',num2str(robot_no_to_move),'.translation'));
              end
              if strcmp('z',dirc(2))
                  if i==1
                    eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)+0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)+0.5]'));
                  end
                  eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['1',' ','0',' ','0',' ',num2str(deg2rad(90/steps*i))],']'));
                  %Changing center back to zero after moving/animating the robot
                  if i==60
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans',num2str(robot_no_to_move),'(1) last_robot_trans',num2str(robot_no_to_move),'(2) last_robot_trans',num2str(robot_no_to_move),'(3)+1]'));
                      eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
                      robots_pos(robot_no_to_move,:)=pos;
                      robots_pos_center = robots_pos-0.5;
                  end
              elseif strcmp('x',dirc(2))
                  if i==1
                    eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)+0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)+0.5]'));
                  end
                  eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['0',' ','0',' ','1',' ',num2str(deg2rad(-90/steps*i))],']'));
                  %Changing center back to zero after moving/animating the robot
                  if i==60
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans',num2str(robot_no_to_move),'(1)+1 last_robot_trans',num2str(robot_no_to_move),'(2) last_robot_trans',num2str(robot_no_to_move),'(3)]'));
                      eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
                      robots_pos(robot_no_to_move,:)=pos;
                      robots_pos_center = robots_pos-0.5;
                  end
              end
          case 2
              %%
              if i==1
                  eval(strcat('last_robot_trans',num2str(robot_no_to_move),' = mynw.robot',num2str(robot_no_to_move),'.translation'));
              end
              if strcmp('z',dirc(2))
                  if i==1
                    eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)+0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)+0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)+0.5]'));
                  end
                  eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['1',' ','0',' ','0',' ',num2str(deg2rad(180/steps*i))],']'));
                  %Changing center back to zero after moving/animating the robot
                  if i==60
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans',num2str(robot_no_to_move),'(1) last_robot_trans',num2str(robot_no_to_move),'(2)+1 last_robot_trans',num2str(robot_no_to_move),'(3)+1]'));
                      eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
                      robots_pos(robot_no_to_move,:)=pos;
                      robots_pos_center = robots_pos-0.5;
                  end
              elseif strcmp('x',dirc(2))
                  if i==1
                    eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)+0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)+0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)+0.5]'));
                  end
                  eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['0',' ','0',' ','1',' ',num2str(deg2rad(-180/steps*i))],']'));
                  %Changing center back to zero after moving/animating the robot
                  if i==60
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans',num2str(robot_no_to_move),'(1)+1 last_robot_trans',num2str(robot_no_to_move),'(2)+1 last_robot_trans',num2str(robot_no_to_move),'(3)]'));
                      eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
                      robots_pos(robot_no_to_move,:)=pos;
                      robots_pos_center = robots_pos-0.5;
                  end
              end
          case 3
              %%
              if i==1
                  eval(strcat('last_robot_trans',num2str(robot_no_to_move),' = mynw.robot',num2str(robot_no_to_move),'.translation'));
              end
              if strcmp('z',dirc(2))
                  if i==1
                    eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)+0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)+0.5]'));
                  end
                  eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['1',' ','0',' ','0',' ',num2str(deg2rad(90/steps*i))],']'));
                  %Changing center back to zero after moving/animating the robot
                  if i==60
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans',num2str(robot_no_to_move),'(1) last_robot_trans',num2str(robot_no_to_move),'(2) last_robot_trans',num2str(robot_no_to_move),'(3)+1]'));
                      for aa=1:10
                          eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[mynw.robot',num2str(robot_no_to_move),'.translation(1),mynw.robot',num2str(robot_no_to_move),'.translation(2)-',num2str(0.1),',mynw.robot',num2str(robot_no_to_move),'.translation(3)]'));
                          pause(0.01);
                      end
                      eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
                      robots_pos(robot_no_to_move,:)=pos;
                      robots_pos_center = robots_pos-0.5;
                  end
              elseif strcmp('x',dirc(2))
                  if i==1
                    eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)+0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)+0.5]'));
                  end
                  eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['0',' ','0',' ','1',' ',num2str(deg2rad(-90/steps*i))],']'));
                  %Changing center back to zero after moving/animating the robot
                  if i==60
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans',num2str(robot_no_to_move),'(1)+1 last_robot_trans',num2str(robot_no_to_move),'(2) last_robot_trans',num2str(robot_no_to_move),'(3)]'));
                      for aa=1:10
                          eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[mynw.robot',num2str(robot_no_to_move),'.translation(1),mynw.robot',num2str(robot_no_to_move),'.translation(2)-',num2str(0.1),',mynw.robot',num2str(robot_no_to_move),'.translation(3)]'));
                          pause(0.01);
                      end
                      eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
                      robots_pos(robot_no_to_move,:)=pos;
                      robots_pos_center = robots_pos-0.5;
                  end
              end
          case 4
              %%
              if i==1
                  eval(strcat('last_robot_trans',num2str(robot_no_to_move),' = mynw.robot',num2str(robot_no_to_move),'.translation'));
              end
              if strcmp('z',dirc(2))
                  if i==1
                    eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)+0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)-0.5]'));
                  end
                  eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['1',' ','0',' ','0',' ',num2str(deg2rad(-180/steps*i))],']'));
                  %Changing center back to zero after moving/animating the robot
                  if i==60
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans',num2str(robot_no_to_move),'(1) last_robot_trans',num2str(robot_no_to_move),'(2)+1 last_robot_trans',num2str(robot_no_to_move),'(3)-1]'));
                      eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
                      robots_pos(robot_no_to_move,:)=pos;
                      robots_pos_center = robots_pos-0.5;
                  end
              elseif strcmp('x',dirc(2))
                  if i==1
                    eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)+0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)-0.5]'));
                  end
                  eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['0',' ','0',' ','1',' ',num2str(deg2rad(180/steps*i))],']'));
                  %Changing center back to zero after moving/animating the robot
                  if i==60
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans',num2str(robot_no_to_move),'(1)-1 last_robot_trans',num2str(robot_no_to_move),'(2)+1 last_robot_trans',num2str(robot_no_to_move),'(3)]'));
                      eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
                      robots_pos(robot_no_to_move,:)=pos;
                      robots_pos_center = robots_pos-0.5;
                  end
              end
          case 5
              %%
              if i==1
                  eval(strcat('last_robot_trans',num2str(robot_no_to_move),' = mynw.robot',num2str(robot_no_to_move),'.translation'));
              end
              if strcmp('z',dirc(2))
                  if i==1
                    eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)-0.5]'));
                  end
                  eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['1',' ','0',' ','0',' ',num2str(deg2rad(-90/steps*i))],']'));
                  %Changing center back to zero after moving/animating the robot
                  if i==60
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans',num2str(robot_no_to_move),'(1) last_robot_trans',num2str(robot_no_to_move),'(2) last_robot_trans',num2str(robot_no_to_move),'(3)-1]'));
                      eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
                      robots_pos(robot_no_to_move,:)=pos;
                      robots_pos_center = robots_pos-0.5;
                  end
              elseif strcmp('x',dirc(2))
                  if i==1
                    eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)-0.5]'));
                  end
                  eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['0',' ','0',' ','1',' ',num2str(deg2rad(90/steps*i))],']'));
                  %Changing center back to zero after moving/animating the robot
                  if i==60
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans',num2str(robot_no_to_move),'(1)-1 last_robot_trans',num2str(robot_no_to_move),'(2) last_robot_trans',num2str(robot_no_to_move),'(3)]'));
                      eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
                      robots_pos(robot_no_to_move,:)=pos;
                      robots_pos_center = robots_pos-0.5;
                  end
              end
          case 6
              %%
              if i==1
                  eval(strcat('last_robot_trans',num2str(robot_no_to_move),' = mynw.robot',num2str(robot_no_to_move),'.translation'));
              end
              if strcmp('z',dirc(2))
                  if i==1
                    eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)-0.5]'));
                  end
                  eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['1',' ','0',' ','0',' ',num2str(deg2rad(-180/steps*i))],']'));
                  %Changing center back to zero after moving/animating the robot
                  if i==60
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans',num2str(robot_no_to_move),'(1) last_robot_trans',num2str(robot_no_to_move),'(2)-1 last_robot_trans',num2str(robot_no_to_move),'(3)-1]'));
                      eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
                      robots_pos(robot_no_to_move,:)=pos;
                      robots_pos_center = robots_pos-0.5;
                  end
              elseif strcmp('x',dirc(2))
                  if i==1
                    eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)-0.5]'));
                  end
                  eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['0',' ','0',' ','1',' ',num2str(deg2rad(180/steps*i))],']'));
                  %Changing center back to zero after moving/animating the robot
                  if i==60
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans',num2str(robot_no_to_move),'(1)-1 last_robot_trans',num2str(robot_no_to_move),'(2)-1 last_robot_trans',num2str(robot_no_to_move),'(3)]'));
                      eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
                      robots_pos(robot_no_to_move,:)=pos;
                      robots_pos_center = robots_pos-0.5;
                  end
              end
          case 7
              %%
              if i==1
                  eval(strcat('last_robot_trans',num2str(robot_no_to_move),' = mynw.robot',num2str(robot_no_to_move),'.translation'));
              end
              if strcmp('z',dirc(2))
                  if i==1
                    eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)-0.5]'));
                  end
                  eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['1',' ','0',' ','0',' ',num2str(deg2rad(-90/steps*i))],']'));
                  %Changing center back to zero after moving/animating the robot
                  if i==60
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans',num2str(robot_no_to_move),'(1) last_robot_trans',num2str(robot_no_to_move),'(2) last_robot_trans',num2str(robot_no_to_move),'(3)-1]'));
                      for aa=1:10
                          eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[mynw.robot',num2str(robot_no_to_move),'.translation(1),mynw.robot',num2str(robot_no_to_move),'.translation(2)-',num2str(0.1),',mynw.robot',num2str(robot_no_to_move),'.translation(3)]'));
                          pause(0.01);
                      end
                      eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
                      robots_pos(robot_no_to_move,:)=pos;
                      robots_pos_center = robots_pos-0.5;
                  end
              elseif strcmp('x',dirc(2))
                  if i==1
                    eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)-0.5]'));
                  end
                  eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['0',' ','0',' ','1',' ',num2str(deg2rad(90/steps*i))],']'));
                  %Changing center back to zero after moving/animating the robot
                  if i==60
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans',num2str(robot_no_to_move),'(1)-1 last_robot_trans',num2str(robot_no_to_move),'(2) last_robot_trans',num2str(robot_no_to_move),'(3)]'));
                      for aa=1:10
                          eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[mynw.robot',num2str(robot_no_to_move),'.translation(1),mynw.robot',num2str(robot_no_to_move),'.translation(2)-',num2str(0.1),',mynw.robot',num2str(robot_no_to_move),'.translation(3)]'));
                          pause(0.01);
                      end
                      eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
                      robots_pos(robot_no_to_move,:)=pos;
                      robots_pos_center = robots_pos-0.5;
                  end
              end
          case 8
              %%
              if i==1
                  eval(strcat('last_robot_trans',num2str(robot_no_to_move),' = mynw.robot',num2str(robot_no_to_move),'.translation'));
              end
              if strcmp('z',dirc(2))
                  if i==1
                    eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)+0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)+0.5]'));
                  end
                  eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['1',' ','0',' ','0',' ',num2str(deg2rad(180/steps*i))],']'));
                  %Changing center back to zero after moving/animating the robot
                  if i==60
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans',num2str(robot_no_to_move),'(1) last_robot_trans',num2str(robot_no_to_move),'(2)-1 last_robot_trans',num2str(robot_no_to_move),'(3)+1]'));
                      eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
                      robots_pos(robot_no_to_move,:)=pos;
                      robots_pos_center = robots_pos-0.5;
                  end
              elseif strcmp('x',dirc(2))
                  if i==1
                    eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)+0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)+0.5]'));
                  end
                  eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['0',' ','0',' ','1',' ',num2str(deg2rad(-180/steps*i))],']'));
                  %Changing center back to zero after moving/animating the robot
                  if i==60
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans',num2str(robot_no_to_move),'(1)+1 last_robot_trans',num2str(robot_no_to_move),'(2)-1 last_robot_trans',num2str(robot_no_to_move),'(3)]'));
                      eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
                      robots_pos(robot_no_to_move,:)=pos;
                      robots_pos_center = robots_pos-0.5;
                  end
              end
          otherwise 
             robots_pos = robots_pos;
      end
   end
   pause(0.001);
end
%====================================================
%%

end
%====================================================