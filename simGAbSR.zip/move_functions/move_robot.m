function [robots_pos] = move_robot(mynw,robots_pos,robot_to_move,axis,dir)
    size_floor=mynw.Floor.children.geometry.size;    
    if axis=='x' && dir>0
        for i=1:dir
            x_axis = size_floor(1);
            eval(strcat('pos = mynw.robot',num2str(robot_to_move),'.translation+0.5;'));
            if pos(1)==x_axis
                robots_pos = robots_pos;
                disp('Robot cannot move...');
                return;
            else
                [robots_pos,~,~] = move_robot_x(mynw,robots_pos,robot_to_move,1);
            end
        end
    elseif axis=='x' && dir<0
        for i=1:abs(dir)
            eval(strcat('pos = mynw.robot',num2str(robot_to_move),'.translation+0.5;'));
            if pos(1)==1
                robots_pos = robots_pos;
                disp('Robot cannot move...');
                return;
            else
                [robots_pos,~,~] = move_robot_x(mynw,robots_pos,robot_to_move,-1);
            end
        end
    elseif axis=='z' && dir>0
        for i=1:dir
            z_axis = size_floor(3);
            eval(strcat('pos = mynw.robot',num2str(robot_to_move),'.translation+0.5;'));
            if pos(3)==z_axis
                robots_pos = robots_pos;
                disp('Robot cannot move...');
                return;
            else
                [robots_pos,~,~] = move_robot_z(mynw,robots_pos,robot_to_move,1);
            end
        end
    elseif axis=='z' && dir<0
        for i=1:abs(dir)
            eval(strcat('pos = mynw.robot',num2str(robot_to_move),'.translation+0.5;'));
            if pos(3)==1
                robots_pos = robots_pos;
                disp('Robot cannot move...');
                return;
            else
                [robots_pos,~,~] = move_robot_z(mynw,robots_pos,robot_to_move,-1);
            end
        end
    end
end