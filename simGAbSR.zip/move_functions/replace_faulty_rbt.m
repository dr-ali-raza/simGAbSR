function [robots_pos] = replace_faulty_rbt(mynw,robots_pos,robots_pos_targ,robt_no)
    robots_pos_center = robots_pos-0.5;
    for i=1:length(robt_no)
        robots_pos_backup = robots_pos(robt_no(i),:);
        faulty_pos = length(robots_pos)+1;        
        rprob = faulty_pos;
        repla = 0;
        if ismember(robots_pos(robt_no(i),:),robots_pos_targ,'rows')
            repla = 0;
        elseif ~ismember(robots_pos(robt_no(i),:),robots_pos_targ,'rows')
            robots_pos(robt_no(i),:)=[1.0 1.0 1.0];
            robots_pos(faulty_pos,:)=robots_pos_backup;
            robots_pos_center = robots_pos-0.5;
            rpoldrob = robt_no(i);
            eval(strcat('delete(mynw.robot',num2str(rpoldrob),')'));
            repla = 1;
        end
        
        pause(0.1);
        %%
        if repla == 1
            robot = vrnode(mynw,strcat('robot',num2str(rpoldrob)),'Transform');
            robot_shape = vrnode(robot,'children',strcat('RobotShape',num2str(rpoldrob)),'Shape');
            robot_Apper = vrnode(robot_shape,'appearance',strcat('RobotAppearance',num2str(rpoldrob)),'Appearance');
            robot_box_size = vrnode(robot_shape,'geometry',strcat('RobotBox',num2str(rpoldrob)),'Box');
            robot_box_size.size = [1 1 1];
            robot.translation = [robots_pos_center(rpoldrob,1) robots_pos_center(rpoldrob,2) robots_pos_center(rpoldrob,3)];
            image_size = 50;
            x=255*rand*ones(image_size);
            a = insertText(x,[round(image_size*30/100) round(image_size*20/100)],rpoldrob,'FontSize',18,'BoxColor','blue','BoxOpacity',1.0,'TextColor','yellow');
            imwrite(a,strcat('images_robot_texture/robot',num2str(rpoldrob),'_im.png'));
            robot_texture = vrnode(robot_Apper,'texture',strcat('RobotTexture',num2str(rpoldrob)),'PixelTexture');
            robot_texture.image = imread(strcat('images_robot_texture/robot',num2str(rpoldrob),'_im.png'));
            robot_texture.repeatS = 'true';
            robot_texture.repeatT = 'true';
            %%
            %%
            robot = vrnode(mynw,strcat('robot',num2str(rprob)),'Transform');
            robot_shape = vrnode(robot,'children',strcat('RobotShape',num2str(rprob)),'Shape');
            robot_Apper = vrnode(robot_shape,'appearance',strcat('RobotAppearance',num2str(rprob)),'Appearance');
            % robot_Mat = vrnode(robot_Apper,'material',strcat('RobotMaterial',num2str(i)),'Material');
            % robot_Mat.diffuseColor = [rand(1) rand(1) rand(1)]
            robot_box_size = vrnode(robot_shape,'geometry',strcat('RobotBox',num2str(rprob)),'Box');
            robot_box_size.size = [1 1 1];
            robot.translation = [robots_pos_center(rprob,1) robots_pos_center(rprob,2) robots_pos_center(rprob,3)];
            % robot.center = [robots_pos_center(1,1) 0.5 robots_pos_center(1,2)]
            image_size = 50;
            x=zeros(image_size);
            a = insertText(x,[round(image_size*30/100) round(image_size*20/100)],'F','FontSize',18,'BoxColor','blue','BoxOpacity',1.0,'TextColor','yellow');
            imwrite(a,strcat('images_robot_texture/robot',num2str(rprob),'_im.png'));
            robot_texture = vrnode(robot_Apper,'texture',strcat('RobotTexture',num2str(rprob)),'PixelTexture');
            robot_texture.image = imread(strcat('images_robot_texture/robot',num2str(rprob),'_im.png'));
            robot_texture.repeatS = 'true';
            robot_texture.repeatT = 'true';
            %%
        end
        
        %%
        
    end
end