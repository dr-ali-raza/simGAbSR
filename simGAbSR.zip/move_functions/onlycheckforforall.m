for i=1:90
   mynw.robot1.rotation=[1.0 0 0 deg2rad(i)]
   mynw.robot2.rotation=[1.0 0 0 deg2rad(i)]
   mynw.robot3.rotation=[1.0 0 0 deg2rad(i)]
   pause(0.01)
end