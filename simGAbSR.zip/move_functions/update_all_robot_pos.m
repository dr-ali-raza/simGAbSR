function [robots_pos] = update_all_robot_pos(mynw,robots_pos,total_no_of_robots)
    for i=1:total_no_of_robots
        eval(strcat('pos = mynw.robot',num2str(i),'.translation+0.5;'));
        robots_pos(i,:)=pos;
    end
end