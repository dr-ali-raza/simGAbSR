function [robots_pos_matrix, robots_pos_center_matrix] = set_robot_pos(mynw,robots_pos_matrix,robots_pos_center_matrix,robot_new_pos_array,robot_no)
    robots_pos_center_matrix(robot_no,:) = robot_new_pos_array-0.5;
    robots_pos_matrix(robot_no,:) = robot_new_pos_array;
    
end