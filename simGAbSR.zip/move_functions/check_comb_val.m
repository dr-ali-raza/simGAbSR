% check as well as make the combinations as well to calculate all the
% fitness values
function [Offsprings,new_values,new_value_best,ppy] = check_comb_val(mynw,robots_pos,robots_pos_targ,target_mat)
    norbt=size(robots_pos);
    notrg=size(robots_pos_targ);
    combns = cell(norbt(1),4);
    
    for i=1:notrg
        % the output rows will be eqqual to no of robots
        % columns will be like +x -x +z -z
        mov_str = check_allow_moves(mynw,robots_pos,robots_pos_targ,i);
        combns{i,1} = mov_str{1,1};
        combns{i,2} = mov_str{1,2};
        combns{i,3} = mov_str{1,3};
        combns{i,4} = mov_str{1,4};
    end
    combns(any(cellfun(@isempty,combns),2),:) = []; %delete row with any empty cell
    [x,y] = size(combns);
    ss='';
    for j=1:x
       if j==x
        ss = strcat(ss,'combns(',num2str(j),',:)'); 
       else
        ss = strcat(ss,'combns(',num2str(j),',:),'); 
       end
       
    end
    eval(strcat('APComb = allcomb(',ss,');'));
    Offsprings = uniqueRowsCA(APComb,0);
    [x,y] = size(Offsprings);
    robots_pos_new = robots_pos;
    for i=1:x
       for j=1:y
          vl = Offsprings{i,j};
              % j here is representing robot number
          if isempty(vl)
              robots_pos_new(j,:) = robots_pos(j,:);
          else
              C = strsplit(vl,',');
              if str2num(C{2})==0
                  robots_pos_new(str2num(C{1}),:) = robots_pos(str2num(C{1}),:);
              else
                  if str2num(C{2})==1
                      if strcmp(C{3},'+x')
                          robots_pos_new(str2num(C{1}),:) = [robots_pos(str2num(C{1}),1)+1 robots_pos(str2num(C{1}),2) robots_pos(str2num(C{1}),3)];
                      elseif strcmp(C{3},'+z')
                          robots_pos_new(str2num(C{1}),:) = [robots_pos(str2num(C{1}),1) robots_pos(str2num(C{1}),2) robots_pos(str2num(C{1}),3)+1];
                      end
                  elseif str2num(C{2})==2
                      if strcmp(C{3},'+x')
                          robots_pos_new(str2num(C{1}),:) = [robots_pos(str2num(C{1}),1)+1 robots_pos(str2num(C{1}),2)+1 robots_pos(str2num(C{1}),3)];
                      elseif strcmp(C{3},'+z')
                          robots_pos_new(str2num(C{1}),:) = [robots_pos(str2num(C{1}),1) robots_pos(str2num(C{1}),2)+1 robots_pos(str2num(C{1}),3)+1];
                      end
                  elseif str2num(C{2})==3
                      if strcmp(C{3},'+x')
                          robots_pos_new(str2num(C{1}),:) = [robots_pos(str2num(C{1}),1)+1 robots_pos(str2num(C{1}),2)-1 robots_pos(str2num(C{1}),3)];
                      elseif strcmp(C{3},'+z')
                          robots_pos_new(str2num(C{1}),:) = [robots_pos(str2num(C{1}),1) robots_pos(str2num(C{1}),2)-1 robots_pos(str2num(C{1}),3)+1];
                      end
                  elseif str2num(C{2})==8
                      if strcmp(C{3},'+x')
                          robots_pos_new(str2num(C{1}),:) = [robots_pos(str2num(C{1}),1)+1 robots_pos(str2num(C{1}),2)-1 robots_pos(str2num(C{1}),3)];
                      elseif strcmp(C{3},'+z')
                          robots_pos_new(str2num(C{1}),:) = [robots_pos(str2num(C{1}),1) robots_pos(str2num(C{1}),2)-1 robots_pos(str2num(C{1}),3)+1];
                      end
                  elseif str2num(C{2})==4
                      if strcmp(C{3},'-x')
                          robots_pos_new(str2num(C{1}),:) = [robots_pos(str2num(C{1}),1)-1 robots_pos(str2num(C{1}),2)+1 robots_pos(str2num(C{1}),3)];
                      elseif strcmp(C{3},'-z')
                          robots_pos_new(str2num(C{1}),:) = [robots_pos(str2num(C{1}),1) robots_pos(str2num(C{1}),2)+1 robots_pos(str2num(C{1}),3)-1];
                      end
                  elseif str2num(C{2})==5
                      if strcmp(C{3},'-x')
                          robots_pos_new(str2num(C{1}),:) = [robots_pos(str2num(C{1}),1)-1 robots_pos(str2num(C{1}),2) robots_pos(str2num(C{1}),3)];
                      elseif strcmp(C{3},'-z')
                          robots_pos_new(str2num(C{1}),:) = [robots_pos(str2num(C{1}),1) robots_pos(str2num(C{1}),2) robots_pos(str2num(C{1}),3)-1];
                      end
                  elseif str2num(C{2})==6
                      if strcmp(C{3},'-x')
                          robots_pos_new(str2num(C{1}),:) = [robots_pos(str2num(C{1}),1)-1 robots_pos(str2num(C{1}),2)-1 robots_pos(str2num(C{1}),3)];
                      elseif strcmp(C{3},'-z')
                          robots_pos_new(str2num(C{1}),:) = [robots_pos(str2num(C{1}),1) robots_pos(str2num(C{1}),2)-1 robots_pos(str2num(C{1}),3)-1];
                      end
                  elseif str2num(C{2})==7
                      if strcmp(C{3},'-x')
                          robots_pos_new(str2num(C{1}),:) = [robots_pos(str2num(C{1}),1)-1 robots_pos(str2num(C{1}),2)-1 robots_pos(str2num(C{1}),3)];
                      elseif strcmp(C{3},'-z')
                          robots_pos_new(str2num(C{1}),:) = [robots_pos(str2num(C{1}),1) robots_pos(str2num(C{1}),2)-1 robots_pos(str2num(C{1}),3)-1];
                      end
                  end
              end
          end
       end
       A = robots_pos_new;
       B = unique(A,'rows');
       As = size(A);
       Bs = size(B);
       if As(1)~=Bs(1)
           new_values(i) = Inf;
       else
           robots_pos_new = robots_pos_new(1:notrg,1:3);
           new_values(i) = objective_function(robots_pos_new,robots_pos_targ,target_mat);
           [x,~] = size(robots_pos_new);
           for ckck=1:x
               ckr = robots_pos_new(ckck,:);
               if ckr(1,2)==2 
                   ckrc = ckr;
                   ckrc(1,2) = 1;
                   if ismember(ckrc,robots_pos_new,'rows')
                       
                   else
                       new_values(i) = Inf;
                   end
               end
           end
       end
       %Here to go with fitness value calculation
    end
    new_value_best = min(new_values);
    [x,ppy,q]=find(min(new_values)==new_values);
end