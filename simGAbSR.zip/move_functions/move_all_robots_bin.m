% #Move all robots at the same time....
%====================================================
function [robots_pos] = move_all_robots_bin(mynw,robots_pos,robots_pos_old)
%====================================================
for i=1:length(robots_pos)
    if robots_pos(i,:)==robots_pos_backup(i,:)

    else
        a = robots_pos(i,:);
        b = robots_pos_backup(1,:);
        x = b(1)-a(1);
        y = b(2)-a(2);
        z = b(3)-a(3);
        if x==1 && y==0 && z==0
            
        elseif x==-1 && y==0 && z==0
            
        elseif x==1 && y==1 && z==0
            
        elseif x==-1 && y==1 && z==0
            
        elseif x==1 && y==-1 && z==0
        
        elseif x==-1 && y==-1 && z==0
        
        elseif x==0 && y==0 && z==1
            
        elseif x==0 && y==0 && z==-1
            
        elseif x==0 && y==1 && z==1
            
        elseif x==0 && y==1 && z==-1
            
        elseif x==0 && y==-1 && z==1
        
        elseif x==0 && y==-1 && z==-1
            
        end
        
    end
end

end
%====================================================