function [keyPressed] = waitForYesNoKeypress
keyPressed = 0; % set this to zero until we receive a sensible keypress
while keyPressed == 0 % hang the system until a response is given
    [ keyIsDown, seconds, keyCode ] = KbCheck; % check for keypress
    if find(keyCode) == 89 | find(keyCode) == 78 % 89 = 'y', 78 = 'n'
        keyPressed = find(keyCode);
    end
end