function movement = movecode(fr,fu,up,bu,bk,bd,dn,fd,fdn)
    if fr==0 && fu==0 && up==0 && bu==0 && bk==0 && bd==1 && dn==1 && fd==1 % Rule 1
        movement=1;
    elseif fr==0 && fu==0 && up==0 && bu==0 && bk==1 && bd==1 && dn==1 && fd==1 % Rule 2
        movement=1;
    elseif fr==1 && fu==0 && up==0 && bu==0 && bk==0 && dn==1 % Rule 3
        movement=2;
    elseif fr==0 && fu==0 && up==0 && bu==0 && bk==0 && bd==0 && dn==1 && fd==0 && fdn==0 % Rule 4
        movement=8;
    elseif fr==0 && fu==0 && up==0 && bu==0 && bk==0 && bd==0 && dn==1 && fd==0 && fdn==1 % Rule 5
        movement=0;
    elseif fr==1 && fu==0 && up==0 && bu==0 && bk==0 && bd==1 && dn==1 && fd==1 && fdn==0 % Rule 6
        movement=2;
    elseif fr==1 && fu==0 && up==0 && bu==0 && bk==0 && bd==1 && dn==1 && fd==1 && fdn==1 % Rule 7
        movement=2;
    elseif fr==0 && fu==0 && up==0 && bu==0 && bk==0 && bd==0 && dn==1 && fd==1 && fdn==1 % Rule 8
        movement=1;
    elseif fr==0 && fu==0 && up==0 && bu==0 && bk==0 && bd==0 && dn==1 && fd==1 && fdn==0 % Rule 9
        movement=1;        
    elseif fr==0 && fu==0 && up==0 && bu==0 && bk==0 && bd==1 && dn==1 && fd==0 && fdn==1 % Rule 10
        movement=0;
    elseif fr==0 && fu==0 && up==0 && bu==0 && bk==0 && bd==1 && dn==1 && fd==0 && fdn==0 % Rule 11
        movement=8;
    elseif fr==0 && fu==0 && up==0 && bu==0 && bk==0 && bd==1 && dn==1 && fd==1 && fdn==0 % Rule 12
        movement=1;
    elseif fr==0 && fu==0 && up==0 && bu==0 && bk==0 && bd==1 && dn==1 && fd==1 && fdn==1 % Rule 13
        movement=1;
    elseif fr==0 && fu==0 && up==0 && bu==1 && bk==1 && bd==1 && dn==1 && fd==1 && fdn==1 % Rule 14
        movement=1;
    elseif fr==0 && fu==0 && up==0 && bu==1 && bk==1 && bd==1 && dn==1 && fd==1 && fdn==0 % Rule 15
        movement=1;
    elseif fr==0 && fu==0 && up==0 && bu==0 && bk==1 && bd==1 && dn==1 && fd==0 && fdn==0 % Rule 16
        movement=8;
    elseif fr==0 && fu==0 && up==0 && bu==1 && bk==1 && bd==1 && dn==1 && fd==0 && fdn==0 % Rule 17
        movement=8;
    else
        movement=0;
    end
end