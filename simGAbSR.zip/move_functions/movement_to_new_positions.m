function [robots_pos] = movement_to_new_positions(mynw, movement, robots_pos, axis,robot_no_to_move,m)
steps=60;
pos = robots_pos;
    switch movement
        case 0;
            robots_pos = robots_pos;
        case 1;
            if axis=='x'
                if m==1
                  for i=1:60
                      if i==1
                        eval(strcat('last_robot_trans',num2str(robot_no_to_move),' = mynw.robot',num2str(robot_no_to_move),'.translation'));
                      end
                      if i==1
                        eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)+0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)+0.5]'));
                      end
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['0',' ','0',' ','1',' ',num2str(deg2rad(-90/steps*i))],']'));
                      %Changing center back to zero after moving/animating the robot
                      if i==60
                          eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
                          eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans',num2str(robot_no_to_move),'(1)+1 last_robot_trans',num2str(robot_no_to_move),'(2) last_robot_trans',num2str(robot_no_to_move),'(3)]'));
                          eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
                          robots_pos(robot_no_to_move,:)=pos;
                          robots_pos_center = robots_pos-0.5;
                      end
                      
                  end
                else
                    robots_pos = [robots_pos(1)+1 robots_pos(2) robots_pos(3)];
                end
            elseif axis=='z'
                if m==1
                  for i=1:60
                      if i==1
                        eval(strcat('last_robot_trans',num2str(robot_no_to_move),' = mynw.robot',num2str(robot_no_to_move),'.translation'));
                      end
                      if i==1
                        eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)+0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)+0.5]'));
                      end
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['1',' ','0',' ','0',' ',num2str(deg2rad(90/steps*i))],']'));
                      %Changing center back to zero after moving/animating the robot
                      if i==60
                          eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
                          eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans',num2str(robot_no_to_move),'(1) last_robot_trans',num2str(robot_no_to_move),'(2) last_robot_trans',num2str(robot_no_to_move),'(3)+1]'));
                          eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
                          robots_pos(robot_no_to_move,:)=pos;
                          robots_pos_center = robots_pos-0.5;
                      end
                      
                  end
                else
                   robots_pos = [robots_pos(1) robots_pos(2) robots_pos(3)+1];
                end
            end
        case 2;
            if axis=='x'
                if m==1
                  for i=1:60
                      if i==1
                        eval(strcat('last_robot_trans',num2str(robot_no_to_move),' = mynw.robot',num2str(robot_no_to_move),'.translation'));
                      end
                      if i==1
                        eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)+0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)+0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)+0.5]'));
                      end
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['0',' ','0',' ','1',' ',num2str(deg2rad(-180/steps*i))],']'));
                      %Changing center back to zero after moving/animating the robot
                      if i==60
                          eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
                          eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans',num2str(robot_no_to_move),'(1)+1 last_robot_trans',num2str(robot_no_to_move),'(2)+1 last_robot_trans',num2str(robot_no_to_move),'(3)]'));
                          eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
                          robots_pos(robot_no_to_move,:)=pos;
                          robots_pos_center = robots_pos-0.5;
                      end
                     
                  end
                else
                    robots_pos = [robots_pos(1)+1 robots_pos(2)+1 robots_pos(3)];
                end
            elseif axis=='z'
                if m==1
                  for i=1:60
                      if i==1
                        eval(strcat('last_robot_trans',num2str(robot_no_to_move),' = mynw.robot',num2str(robot_no_to_move),'.translation'));
                      end
                      if i==1
                        eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)+0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)+0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)+0.5]'));
                      end
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['1',' ','0',' ','0',' ',num2str(deg2rad(180/steps*i))],']'));
                      %Changing center back to zero after moving/animating the robot
                      if i==60
                          eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
                          eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans',num2str(robot_no_to_move),'(1) last_robot_trans',num2str(robot_no_to_move),'(2)+1 last_robot_trans',num2str(robot_no_to_move),'(3)+1]'));
                          eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
                          robots_pos(robot_no_to_move,:)=pos;
                          robots_pos_center = robots_pos-0.5;
                      end
                   
                  end
                else
                    robots_pos = [robots_pos(1) robots_pos(2)+1 robots_pos(3)+1];
                end
            end
        case 3;
            if axis=='x'
                if m==1
                  for i=1:60
                      if i==1
                        eval(strcat('last_robot_trans',num2str(robot_no_to_move),' = mynw.robot',num2str(robot_no_to_move),'.translation'));
                      end
                      if i==1
                        eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)+0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)+0.5]'));
                      end
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['0',' ','0',' ','1',' ',num2str(deg2rad(-90/steps*i))],']'));
                      %Changing center back to zero after moving/animating the robot
                      if i==60
                          eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
                          eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans',num2str(robot_no_to_move),'(1)+1 last_robot_trans',num2str(robot_no_to_move),'(2) last_robot_trans',num2str(robot_no_to_move),'(3)]'));
                          for aa=1:10
                              eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[mynw.robot',num2str(robot_no_to_move),'.translation(1),mynw.robot',num2str(robot_no_to_move),'.translation(2)-',num2str(0.1),',mynw.robot',num2str(robot_no_to_move),'.translation(3)]'));
                              pause(0.01);
                          end
                          eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
                          robots_pos(robot_no_to_move,:)=pos;
                          robots_pos_center = robots_pos-0.5;
                      end
                     
                  end
                else
                    robots_pos = [robots_pos(1)+1 robots_pos(2)-1 robots_pos(3)];
                end
            elseif axis=='z'
                if m==1
                  for i=1:60
                      if i==1
                        eval(strcat('last_robot_trans',num2str(robot_no_to_move),' = mynw.robot',num2str(robot_no_to_move),'.translation'));
                      end
                      if i==1
                        eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)+0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)+0.5]'));
                      end
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['1',' ','0',' ','0',' ',num2str(deg2rad(90/steps*i))],']'));
                      %Changing center back to zero after moving/animating the robot
                      if i==60
                          eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
                          eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans',num2str(robot_no_to_move),'(1) last_robot_trans',num2str(robot_no_to_move),'(2) last_robot_trans',num2str(robot_no_to_move),'(3)+1]'));
                          for aa=1:10
                              eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[mynw.robot',num2str(robot_no_to_move),'.translation(1),mynw.robot',num2str(robot_no_to_move),'.translation(2)-',num2str(0.1),',mynw.robot',num2str(robot_no_to_move),'.translation(3)]'));
                              pause(0.01);
                          end
                          eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
                          robots_pos(robot_no_to_move,:)=pos;
                          robots_pos_center = robots_pos-0.5;
                      end
                      
                  end
                else
                    robots_pos = [robots_pos(1) robots_pos(2)-1 robots_pos(3)+1];
                end
            end
        case 4;
            if axis=='x'
                if m==1
                  for i=1:60
                      if i==1
                        eval(strcat('last_robot_trans',num2str(robot_no_to_move),' = mynw.robot',num2str(robot_no_to_move),'.translation'));
                      end
                      if i==1
                        eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)+0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)-0.5]'));
                      end
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['0',' ','0',' ','1',' ',num2str(deg2rad(180/steps*i))],']'));
                      %Changing center back to zero after moving/animating the robot
                      if i==60
                          eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
                          eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans',num2str(robot_no_to_move),'(1)-1 last_robot_trans',num2str(robot_no_to_move),'(2)+1 last_robot_trans',num2str(robot_no_to_move),'(3)]'));
                          eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
                          robots_pos(robot_no_to_move,:)=pos;
                          robots_pos_center = robots_pos-0.5;
                      end
                      
                  end
                else
                    robots_pos = [robots_pos(1)-1 robots_pos(2)+1 robots_pos(3)];
                end
            elseif axis=='z'
                if m==1
                  for i=1:60
                      if i==1
                        eval(strcat('last_robot_trans',num2str(robot_no_to_move),' = mynw.robot',num2str(robot_no_to_move),'.translation'));
                      end
                      if i==1
                        eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)+0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)-0.5]'));
                      end
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['1',' ','0',' ','0',' ',num2str(deg2rad(-180/steps*i))],']'));
                      %Changing center back to zero after moving/animating the robot
                      if i==60
                          eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
                          eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans',num2str(robot_no_to_move),'(1) last_robot_trans',num2str(robot_no_to_move),'(2)+1 last_robot_trans',num2str(robot_no_to_move),'(3)-1]'));
                          eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
                          robots_pos(robot_no_to_move,:)=pos;
                          robots_pos_center = robots_pos-0.5;
                      end
                      
                  end
                else
                    robots_pos = [robots_pos(1) robots_pos(2)+1 robots_pos(3)-1];
                end
            end
        case 5;
            if axis=='x'
                if m==1
                  for i=1:60
                      if i==1
                        eval(strcat('last_robot_trans',num2str(robot_no_to_move),' = mynw.robot',num2str(robot_no_to_move),'.translation'));
                      end
                      if i==1
                        eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)-0.5]'));
                      end
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['0',' ','0',' ','1',' ',num2str(deg2rad(90/steps*i))],']'));
                      %Changing center back to zero after moving/animating the robot
                      if i==60
                          eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
                          eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans',num2str(robot_no_to_move),'(1)-1 last_robot_trans',num2str(robot_no_to_move),'(2) last_robot_trans',num2str(robot_no_to_move),'(3)]'));
                          eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
                          robots_pos(robot_no_to_move,:)=pos;
                          robots_pos_center = robots_pos-0.5;
                      end
                      
                  end
                else
                    robots_pos = [robots_pos(1)-1 robots_pos(2) robots_pos(3)];
                end
            elseif axis=='z'
                if m==1
                  for i=1:60
                      if i==1
                        eval(strcat('last_robot_trans',num2str(robot_no_to_move),' = mynw.robot',num2str(robot_no_to_move),'.translation'));
                      end
                      if i==1
                        eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)-0.5]'));
                      end
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['1',' ','0',' ','0',' ',num2str(deg2rad(-90/steps*i))],']'));
                      %Changing center back to zero after moving/animating the robot
                      if i==60
                          eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
                          eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans',num2str(robot_no_to_move),'(1) last_robot_trans',num2str(robot_no_to_move),'(2) last_robot_trans',num2str(robot_no_to_move),'(3)-1]'));
                          eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
                          robots_pos(robot_no_to_move,:)=pos;
                          robots_pos_center = robots_pos-0.5;
                      end
                      
                  end
                else
                    robots_pos = [robots_pos(1) robots_pos(2) robots_pos(3)-1];
                end
            end
        case 6;
            if axis=='x'
                if m==1
                  for i=1:60
                      if i==1
                        eval(strcat('last_robot_trans',num2str(robot_no_to_move),' = mynw.robot',num2str(robot_no_to_move),'.translation'));
                      end
                      if i==1
                        eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)-0.5]'));
                      end
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['0',' ','0',' ','1',' ',num2str(deg2rad(180/steps*i))],']'));
                      %Changing center back to zero after moving/animating the robot
                      if i==60
                          eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
                          eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans',num2str(robot_no_to_move),'(1)-1 last_robot_trans',num2str(robot_no_to_move),'(2)-1 last_robot_trans',num2str(robot_no_to_move),'(3)]'));
                          eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
                          robots_pos(robot_no_to_move,:)=pos;
                          robots_pos_center = robots_pos-0.5;
                      end
                      
                  end
                else
                    robots_pos = [robots_pos(1)-1 robots_pos(2)-1 robots_pos(3)];
                end
            elseif axis=='z'
                if m==1
                  for i=1:60
                      if i==1
                        eval(strcat('last_robot_trans',num2str(robot_no_to_move),' = mynw.robot',num2str(robot_no_to_move),'.translation'));
                      end
                      if i==1
                        eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)-0.5]'));
                      end
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['1',' ','0',' ','0',' ',num2str(deg2rad(-180/steps*i))],']'));
                      %Changing center back to zero after moving/animating the robot
                      if i==60
                          eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
                          eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans',num2str(robot_no_to_move),'(1) last_robot_trans',num2str(robot_no_to_move),'(2)-1 last_robot_trans',num2str(robot_no_to_move),'(3)-1]'));
                          eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
                          robots_pos(robot_no_to_move,:)=pos;
                          robots_pos_center = robots_pos-0.5;
                      end
                      
                  end
                else
                    robots_pos = [robots_pos(1) robots_pos(2)-1 robots_pos(3)-1];
                end
            end
        case 7;
            if axis=='x'
                if m==1
                  for i=1:60
                      if i==1
                        eval(strcat('last_robot_trans',num2str(robot_no_to_move),' = mynw.robot',num2str(robot_no_to_move),'.translation'));
                      end
                      if i==1
                        eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)-0.5]'));
                      end
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['0',' ','0',' ','1',' ',num2str(deg2rad(90/steps*i))],']'));
                      %Changing center back to zero after moving/animating the robot
                      if i==60
                          eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
                          eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans',num2str(robot_no_to_move),'(1)-1 last_robot_trans',num2str(robot_no_to_move),'(2) last_robot_trans',num2str(robot_no_to_move),'(3)]'));
                          for aa=1:10
                              eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[mynw.robot',num2str(robot_no_to_move),'.translation(1),mynw.robot',num2str(robot_no_to_move),'.translation(2)-',num2str(0.1),',mynw.robot',num2str(robot_no_to_move),'.translation(3)]'));
                              pause(0.01);
                          end
                          eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
                          robots_pos(robot_no_to_move,:)=pos;
                          robots_pos_center = robots_pos-0.5;
                      end
                      
                  end
                else
                    robots_pos = [robots_pos(1)-1 robots_pos(2)-1 robots_pos(3)];
                end
            elseif axis=='z'
                if m==1
                  for i=1:60
                      if i==1
                        eval(strcat('last_robot_trans',num2str(robot_no_to_move),' = mynw.robot',num2str(robot_no_to_move),'.translation'));
                      end
                      if i==1
                        eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)-0.5]'));
                      end
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['1',' ','0',' ','0',' ',num2str(deg2rad(-90/steps*i))],']'));
                      %Changing center back to zero after moving/animating the robot
                      if i==60
                          eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
                          eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans',num2str(robot_no_to_move),'(1) last_robot_trans',num2str(robot_no_to_move),'(2) last_robot_trans',num2str(robot_no_to_move),'(3)-1]'));
                          for aa=1:10
                              eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[mynw.robot',num2str(robot_no_to_move),'.translation(1),mynw.robot',num2str(robot_no_to_move),'.translation(2)-',num2str(0.1),',mynw.robot',num2str(robot_no_to_move),'.translation(3)]'));
                              pause(0.01);
                          end
                          eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
                          robots_pos(robot_no_to_move,:)=pos;
                          robots_pos_center = robots_pos-0.5;
                      end
                      
                  end
                else
                    robots_pos = [robots_pos(1) robots_pos(2)-1 robots_pos(3)-1];
                end
            end
        case 8;
            if axis=='x'
                if m==1
                  for i=1:60
                      if i==1
                        eval(strcat('last_robot_trans',num2str(robot_no_to_move),' = mynw.robot',num2str(robot_no_to_move),'.translation'));
                      end
                      if i==1
                        eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)+0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)+0.5]'));
                      end
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['0',' ','0',' ','1',' ',num2str(deg2rad(-180/steps*i))],']'));
                      %Changing center back to zero after moving/animating the robot
                      if i==60
                          eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
                          eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans',num2str(robot_no_to_move),'(1)+1 last_robot_trans',num2str(robot_no_to_move),'(2)-1 last_robot_trans',num2str(robot_no_to_move),'(3)]'));
                          eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
                          robots_pos(robot_no_to_move,:)=pos;
                          robots_pos_center = robots_pos-0.5;
                      end
                      
                  end
                else
                    robots_pos = [robots_pos(1)+1 robots_pos(2)-1 robots_pos(3)];
                end
            elseif axis=='z'
                if m==1
                  for i=1:60
                      if i==1
                        eval(strcat('last_robot_trans',num2str(robot_no_to_move),' = mynw.robot',num2str(robot_no_to_move),'.translation'));
                      end
                      if i==1
                        eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)+0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)+0.5]'));
                      end
                      eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['1',' ','0',' ','0',' ',num2str(deg2rad(180/steps*i))],']'));
                      %Changing center back to zero after moving/animating the robot
                      if i==60
                          eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
                          eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans',num2str(robot_no_to_move),'(1) last_robot_trans',num2str(robot_no_to_move),'(2)-1 last_robot_trans',num2str(robot_no_to_move),'(3)+1]'));
                          eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
                          robots_pos(robot_no_to_move,:)=pos;
                          robots_pos_center = robots_pos-0.5;
                      end
                      
                  end
                else
                    robots_pos = [robots_pos(1) robots_pos(2)-1 robots_pos(3)+1];
                end
            end
            pause(0.01);
    end
    if m==1
        robots_pos = pos ;
    end
    
end