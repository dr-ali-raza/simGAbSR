function [robots_pos,robots_pos_center,movement] = move_robot_z(mynw,robots_pos,robot_no_to_move,dir)
        robots_pos_center = robots_pos-0.5;
        sensor_v = get_sensor_z(mynw,robots_pos,robot_no_to_move,dir);
        %Checking Direction and then using the respective fuzzy logic 
        if dir>0
            movement = movecode(sensor_v(1),sensor_v(2),sensor_v(3),sensor_v(4),sensor_v(5),sensor_v(6),sensor_v(7),sensor_v(8),sensor_v(9));                           
            if movement == 1 || movement == 2 || movement == 8
                
            else
                if movement==0 && sensor_v(9)==1
                   movement =3;
                else
                   movement =0; 
                end
            end
        elseif dir<0
            movement = movecode(sensor_v(1),sensor_v(2),sensor_v(3),sensor_v(4),sensor_v(5),sensor_v(6),sensor_v(7),sensor_v(8),sensor_v(9));                           
            if movement == 1 || movement == 2 || movement == 8
                if movement == 1
                    movement = 5;
                elseif movement == 2
                    movement = 4;
                elseif movement == 8
                    movement = 6;
                end  
            else
                if movement==0 && sensor_v(9)==1
                   movement =7;
                else
                   movement =0; 
                end
            end
        end
        % checking level of robot and then allow whether to move up side or
        % no
        robp = robots_pos(robot_no_to_move,:);
        if robp(2)>1
            if movement == 2 || movement == 4
               movement = 0 ;
               return; 
            end
        end
        %Changing the center to corner so that when we rotate the block it must move in next block area
        eval(strcat('last_robot_center = mynw.robot',num2str(robot_no_to_move),'.center'));
        eval(strcat('last_robot_trans = mynw.robot',num2str(robot_no_to_move),'.translation'));
        %eval(strcat('last_angle=round(rad2deg(mynw.robot',num2str(robot_no_to_move),'.rotation(4)))'));
        
        %=====================================================================================================================
        if movement==1
            %=====================================================================================================================
            eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)+0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)+0.5]'));
            steps=60;
            for j=1:steps
                eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['1',' ','0',' ','0',' ',num2str(deg2rad(90/steps*j))],']'));
                pause(0.01);
            end
            %Changing center back to zero after moving/animating the robot
            eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
            eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans(1) last_robot_trans(2) last_robot_trans(3)+1]'));
            eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
            robots_pos(robot_no_to_move,:)=pos;
            robots_pos_center = robots_pos-0.5;
           %  return;
        elseif movement==2
            eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)+0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)+0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)+0.5]'));
            steps=60;
            for j=1:steps
                eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['1',' ','0',' ','0',' ',num2str(deg2rad(180/steps*j))],']'));
                pause(0.01);
            end
            %Changing back center to zero after moving/animating the robot
            eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
            eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans(1) last_robot_trans(2)+1 last_robot_trans(3)+1]'));
            eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
            robots_pos(robot_no_to_move,:)=pos;
             robots_pos_center = robots_pos-0.5;
            %  return;
        elseif movement==3
             %=====================================================================================================================
            eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)+0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)+0.5]'));
            steps=60;
            for j=1:steps
                eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['1',' ','0',' ','0',' ',num2str(deg2rad(90/steps*j))],']'));
                pause(0.01);
            end
            eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
            eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans(1) last_robot_trans(2) last_robot_trans(3)+1]'));
            for aa=1:10
                eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[mynw.robot',num2str(robot_no_to_move),'.translation(1),mynw.robot',num2str(robot_no_to_move),'.translation(2)-',num2str(0.1),',mynw.robot',num2str(robot_no_to_move),'.translation(3)]'));
                pause(0.01);
            end
            %Changing center back to zero after moving/animating the robot
            eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
            robots_pos(robot_no_to_move,:)=pos;
            robots_pos_center = robots_pos-0.5;
        elseif movement==8
            eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)+0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)+0.5]'));
            steps=60;
            for j=1:steps
                eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['1',' ','0',' ','0',' ',num2str(deg2rad(180/steps*j))],']'));
                pause(0.01);
            end
            %Changing center back to zero after moving/animating the robot
            eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
            eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans(1) last_robot_trans(2)-1 last_robot_trans(3)+1]'));
            eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
            robots_pos(robot_no_to_move,:)=pos;
            robots_pos_center = robots_pos-0.5;
            %  return;
        elseif movement==4
            eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)+0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)-0.5]'));
            steps=60;
            for j=1:steps
                eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['1',' ','0',' ','0',' ',num2str(deg2rad(-180/steps*j))],']'));
                pause(0.01);
            end
            %Changing center back to zero after moving/animating the robot
            eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
            eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans(1) last_robot_trans(2)+1 last_robot_trans(3)-1]'));
            eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
            robots_pos(robot_no_to_move,:)=pos;
            robots_pos_center = robots_pos-0.5;
            %  return;
        elseif movement==5
            eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)-0.5]'));
            steps=60;
            for j=1:steps
                eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['1',' ','0',' ','0',' ',num2str(deg2rad(-90/steps*j))],']'));
                pause(0.01);
            end
            %Changing center back to zero after moving/animating the robot
            eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
            eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans(1) last_robot_trans(2) last_robot_trans(3)-1]'));
            eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
            robots_pos(robot_no_to_move,:)=pos;
            robots_pos_center = robots_pos-0.5;
            %  return;
        elseif movement==6
            eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[mynw.robot',num2str(robot_no_to_move),'.center(1)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(2)-0.5 mynw.robot',num2str(robot_no_to_move),'.center(3)-0.5]'));
            steps=60;
            for j=1:steps
                eval(strcat('mynw.robot',num2str(robot_no_to_move),'.rotation=[',['1',' ','0',' ','0',' ',num2str(deg2rad(-180/steps*j))],']'));
                pause(0.01);
            end
            %Changing center back to zero after moving/animating the robot
            eval(strcat('mynw.robot',num2str(robot_no_to_move),'.center=[0 0 0]'));
            eval(strcat('mynw.robot',num2str(robot_no_to_move),'.translation=[last_robot_trans(1) last_robot_trans(2)-1 last_robot_trans(3)-1]'));
            eval(strcat('pos = mynw.robot',num2str(robot_no_to_move),'.translation+0.5;'));
            robots_pos(robot_no_to_move,:)=pos;
            robots_pos_center = robots_pos-0.5;
            %  return;
        end
        %=====================================================================================================================
    end