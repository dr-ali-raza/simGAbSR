function [mynw] = init_vrw(template,size_floor)
% Creating Objects in Virtual Rality using code, Initialy call a template 
% from some already build samples, Then create the template object and 
% open it.
mynw = vrworld(template);
open(mynw);
if isvalid(nodes(mynw))
    [x, ~] = size(nodes(mynw));
else
    x=0;
end
if x>0
    % Delete the nodes if already exists in wrl file so that it may be
    % constructed with new parameters...
    delete(nodes(mynw));
end
% ========================================================================
% to check all nodes in vrworld
% mynwn = nodes(mynw);
% ========================================================================
% Command to create a new node in vrworld, reating floor for robots using
% vrnode command
% Command to create Floor in vrworld
floor = vrnode(mynw,'Floor','Transform');
% Creating Directional Lights in vrml File
fdlight = vrnode(mynw,'Lights','DirectionalLight');
fdlight.ambientIntensity = 0.5;
fdlight.color = [0.7 0.7 0.7];
fdlight.on = 'true';
% ========================================================================
% Creating ViewPoint in the simulation environment at an appropreate
% distance from robots to view all robots
view_point = vrnode(mynw,'Observe','Viewpoint');
view_point.description = 'Initial_View';
% view_point position which is [x y z]...
view_point.position = [(size_floor(1))*2.5 (size_floor(1)/2)*1.5 ((size_floor(3)/2))];
angle_rad_view = -deg2rad(atand((size_floor(1)-3)/(size_floor(1)+5)));
view_point.orientation = [-1.5 20.0 1.5 deg2rad(90)];
view_point.set_bind = 'false';
% ========================================================================
% Designing another view
% Creating ViewPoint in the simulation environment at an appropreate
% distance from robots to view all robots
view_point = vrnode(mynw,'Bindable','Viewpoint');
view_point.description = 'Observe_from_top';
% view_point position which is [x y z]...
view_point.position = [-(size_floor(1)) (size_floor(1)/2)*2.0 ((size_floor(3)/2))];
angle_rad_view = -deg2rad(atand((size_floor(1)-3)/(size_floor(1)+5)));
view_point.orientation = [4.0 15.0 4.0 deg2rad(-90)];
view_point.set_bind = 'true';
% ========================================================================
% Creating texture on floor in black and white blocks
fshape = vrnode(floor,'children','FloorShape','Shape');
fappear = vrnode(fshape,'appearance','FloorAppearance','Appearance');
fboxsize = vrnode(fshape,'geometry','FloorBox','Box');
% Getting the name of the field to adjust size of floor and its thickness
% and also checking that whether the floor has 'size' field or no
ffields = get(fboxsize,'Fields');
[i, j] = size(ffields);
for n=1:i
  if strcmp(ffields(n),'size')
      % We can also use command floor.children.size to set or get size of
      % floor
      fboxsize.size = size_floor; 
  else
      % nothing to do or any code to perform...
  end
end
floor.translation = [size_floor(1)/2 -size_floor(2)/2 size_floor(3)/2];
% ========================================================================
ftexture = vrnode(fappear,'texture','','ImageTexture');
ftexture.url = 'check_1.gif';
% ftexture.image = [2 1 1 0 255];
ftexture.repeatS = 'true';
ftexture.repeatT = 'true';
% Creating textureTransform on floor in black and white blocks
ftexture_trans = vrnode(fappear,'textureTransform','','TextureTransform');
ftexture_trans.scale = [size_floor(1)/2 size_floor(3)/2];
% Creating material on floor in black and white blocks
fmaterial = vrnode(fappear,'material','','Material');
fmaterial.diffuseColor = [1 1 1];
fmaterial.ambientIntensity = 1;
% ========================================================================
% view(mynw);
end