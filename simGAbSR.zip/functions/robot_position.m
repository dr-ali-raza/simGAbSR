function [xaxisc,zaxisc,xaxis_block,zaxis_block] = robot_position(mynw,robot_no)
    eval(strcat('xaxisc=mynw.robot',num2str(robot_no),'.translation(1);'));
    eval(strcat('zaxisc=mynw.robot',num2str(robot_no),'.translation(3);'));
    xaxis_block = xaxisc+0.5;
    zaxis_block = zaxisc+0.5;
end