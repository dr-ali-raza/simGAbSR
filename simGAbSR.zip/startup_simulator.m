% Code for GA-based Self Reconfiguration of Modular Robots (Impulse Actuated)
% This code is developed in the AI & Robotics Lab of UET Lahore, Pakistan. 
% One can access the lab-page at http://uet.edu.pk/pp/mct/~aliraza/lab.html
% 
% startup_simulator main file
%% Initial Clearing variable and screen for simulator use
clear all
clc
addpath('functions','images_robot_texture','get_functions','move_functions','plot_functions','ga_functions');
%=========================================================================
%%
% Variables for use in simulator
template_vrml = 'template.wrl'; % Virtual World Variable
nosquare=10; % Floor Size definition
size_of_floor = [nosquare 0.4 nosquare]; % size of floor is adjusted here
number_of_robots = nosquare; % this variable will reperesent number of robots in simulation
robot_placement = 'random1'; % robot placement type defined here
targ_rand = rand(); 
if targ_rand>0.5
    target_name = 'target_placement';
else
    target_name = 'target_placement1';
end
M=size_of_floor(1);
N=size_of_floor(3);
vrsetpref('DefaultFigureTriad','bottomleft');
% vrsetpref('DefaultFigurePosition',[10 100 800 600]);N=size_of_floor(3);
% VRML Viewwer window size adjustment and triad addition

%=========================================================================
%%
target_vrml = 'target.wrl';
targw = init_vrw(target_vrml,size_of_floor);
% fig_world = figure('Name','GA Simulation Plot Window','NumberTitle','off')
% the figure doesn't exist, create one
fig_world = figure('Units','pixels','Position',[50 0 1200 700],'Color',[0.314 0.314 0.314],'Name','GA Based Self-Reconfiguration in Robotics');
chh1=0; % How robots will be placed in arena or simulator
if chh1 == 1
    [targw, robots_pos_targ,robots_pos_targ_center]=init_target_char(targw,number_of_robots,'T');
elseif chh1 == 0
    tt=1;
    [number_of_robots,robots_pos_targ] = get_target_positions(size_of_floor(1),size_of_floor(3),tt);
    place_rbts(targw,robots_pos_targ);
end
clf;
% calling environment initialization fucntion
mynw = init_vrw(template_vrml,size_of_floor);
chh2=0; % initial position definitions in main robot environment
if chh2 == 1
    [mynw, robots_pos,robots_pos_center,rpbfl]=init_robots(mynw,number_of_robots,robot_placement);
    place_rbts(mynw,robots_pos)
elseif chh2 == 0
    tt=2;
    [number_of_robots,robots_pos] = get_target_positions(size_of_floor(1),size_of_floor(3),tt);
    place_rbts(mynw,robots_pos); 
end
clf;
vr.canvas(targw,'Parent',fig_world,'Units', 'normalized','Position', [0.03 0.45 0.45 0.53]); % for target window adjustment
vr.canvas(mynw,'Parent',fig_world,'Units', 'normalized','Position', [0.52 0.45 0.45 0.53]); % for main window adjustment
% Defining Target Situation
target_mat=zeros(M,N);
for i=1:number_of_robots
   target_mat(robots_pos_targ(i,1), robots_pos_targ(i,3))=1;
end
name= 'Target';
G1_Axes = axes('Position', [0.05 0.1 0.18 0.25],'XGrid','on','YGrid','on','Color','k','XColor','w','YColor','w','XLim',[0 Inf]);
display_blocks(target_mat,name);
%=====================================
% Defining Parent 1
parent=zeros(M,N);
robots_pos_parent1 = robots_pos;
for i=1:number_of_robots
   parent(robots_pos_parent1(i,1), robots_pos_parent1(i,3))=1;
end
name= 'Initial Configuration';
G2_Axes = axes('Position', [0.28 0.1 0.18 0.25],'XGrid','on','YGrid','on','Color','k','XColor','w','YColor','w','XLim',[0 Inf]);
display_blocks(parent,name);

G3_Axes = axes('Position', [0.53 0.1 0.18 0.25],'XGrid','on','YGrid','on','Color','k','XColor','w','YColor','w','XLim',[0 Inf]);
%=====================================
%%
robots_pos_saved = robots_pos; % Robot Positions in Main Window
robots_pos_targ_saved = robots_pos_targ; % Robot Positions in Target Window

obj_val = 1;
lp=0;
gen(1)=1;

%% ***************************************************************** %%
    % Genetic Algorithm Code for Reconfiguration Problem
    % Population Size for initialization take size as  
    pop_size = 100;
    % Initialization for Population Matrix
    
    [rx cy] = size(robots_pos_targ);
      pop_mat = zeros(pop_size,rx*2);
      if 2^(rx*2)>pop_size
          
      else
          pop_size=2^(rx*2);
          pop_mat = getcondvects(rx*2);
      end
      
    % Generate pop_size Binary String as Parents
      robots_pos_backup = robots_pos(1:rx,1:3); % To confirm that number of targets and number of robots are equal    
      
      for ps=1:pop_size
          if pop_size~=2^(rx*2)
            pop_mat(ps,:) = rand(1,rx*2)>0.4;  
          end
          % Convert back to robot_pos to check objective function values
          [obj_val(ps,1),~] = generate_robot_positions(mynw,pop_mat(ps,:),robots_pos_backup,robots_pos_targ,target_mat);
          obj_val(ps,2) = ps;
      end
      Concat = [obj_val pop_mat];
      obj_val_bin = sortrows(Concat,1);
      obj_val = obj_val_bin(1:ps,1:2);
      pop_mat = obj_val_bin(1:end,3:end);
      bin_string = pop_mat(1,:);
      [~, robots_pos] = move_to_new_positions(mynw,bin_string,robots_pos_backup,robots_pos_targ,target_mat,1)
while obj_val(1,1)~=0 || gen(lp)==50
    lp=lp+1;
    gen(lp)=lp;
    tic;  
      if (rx-sum(ismember(robots_pos,robots_pos_targ,'rows')))<5
            % Calculation of fitness value
            obj_val(lp) = objective_function(robots_pos_backup,robots_pos_targ,target_mat);

            [Offsprings,new_values,new_value_best,offspring_number] = check_comb_val(mynw,robots_pos,robots_pos_targ,target_mat);
            obj_val(lp) = new_value_best;
            %     robots_pos = robots_pos_backup;
            if length(offspring_number)>1
                randomColumnNumber = randi(size(offspring_number, 2), 1);
                to_achive = Offsprings(offspring_number(1,randomColumnNumber),:);
            else
                to_achive = Offsprings(offspring_number,:);
            end
            %=======================================================
            % Display Strings on generation fitness graph
            to_achive_backup = to_achive;
            to_achive = to_achive(~cellfun(@isempty, to_achive));
            string_to_show = strjoin(to_achive,',');
            title(strcat('New Offspring=',string_to_show),'Color','w');
            %=======================================================
            [robots_pos] = move_all_robots(mynw,to_achive,robots_pos)
            %************************************************
            if isempty(setdiff(ceil(robots_pos),robots_pos_targ,'rows'))
               obj_val(1,1)=0; 
            end
      else
          % Arrange them for crossover
          i=0;
          [x y] = size(pop_mat);
          if 2^(rx*2)>pop_size
                for i=1:2:x
                  aa = [pop_mat(i+1,1:y/2) pop_mat(i,((y/2)+1):end)];
                  bb = [pop_mat(i,1:y/2) pop_mat(i+1,((y/2)+1):end)];
                  pop_mat(i,:) = aa;
                  pop_mat(i+1,:) = bb;
                end
                % Do mutation 
                i=0;
                for i=1:x
                 rn = round(rand*rx*2)
                 if rn==0
                     rn = rn+1;
                 end
                 pop_mat(i,rn) = not(pop_mat(abs(i),abs(rn)));
                end
          else
              pop_size=2^(rx*2);
              pop_mat = getcondvects(rx*2);
          end
          
          % Best One will be selected and recorded and movement will done
            [x y] = size(pop_mat);
              for ps=1:x
                  % Convert back to robot_pos to check objective function values
                  [obj_val(ps,1),~] = generate_robot_positions(mynw,pop_mat(ps,:),robots_pos,robots_pos_targ,target_mat);
                  obj_val(ps,2) = ps;
              end
              obj_val = sortrows(obj_val,1);
            % Loop will go again 
              Concat = [obj_val pop_mat];
             % smallest to largest badness
              obj_val_bin = sortrows(Concat,1);
              obj_val = obj_val_bin(1:ps,1:2);
              pop_mat = obj_val_bin(1:end,3:end);
              bin_string = pop_mat(1,:);
              rbtnchk = 1;
              for i=1:2:length(robots_pos)
                 if ismember(robots_pos(rbtnchk,:),robots_pos_targ,'rows')
                    bin_string(1,i)   = 2;
                    bin_string(1,i+1) = 2;
                 end
                 rbtnchk = rbtnchk+1;
              end
              [~, robots_pos] = move_to_new_positions(mynw,bin_string,robots_pos,robots_pos_targ,target_mat,1)
            %************************************************
            if isempty(setdiff(ceil(robots_pos),robots_pos_targ,'rows'))
               obj_val(1,1)=0;
            end
      end
      time_chk_algo(lp) = toc;
%       pause
      obj_val = sortrows(obj_val,1);
      obj_val_array(lp) = obj_val(1,1);
      
end
   
%=====================================
%%
    %=====================================
    G3_Axes.XTickLabel = gen;
    G3_Axes.YTickLabel = [0 num2str(length(gen))];
    bar(G3_Axes,obj_val_array)
    G3_Axes.Title.String = 'Fitness Evaluation';
    G3_Axes.Title.Color = [1 1 1];
    G3_Axes.XLabel.String = strcat('No of Generations = ',num2str(length(gen)));
    G3_Axes.XLabel.Color = [1 1 1];
    G3_Axes.YLabel.String = 'Evaluated Fitness Value';
    G3_Axes.YLabel.Color = [1 1 1];
    
    G4_Axes = axes('Position', [0.78 0.1 0.18 0.25],'XGrid','on','YGrid','on','Color','k','XColor','w','YColor','w','XLim',[0 Inf]);
    G4_Axes.XTickLabel = gen;
    G4_Axes.YTickLabel = [0 max(time_chk_algo)+2];
    bar(G4_Axes,time_chk_algo)
    G4_Axes.Title.String = 'Algorithm Time Graph';
    G4_Axes.Title.Color = [1 1 1];
    G4_Axes.XLabel.String = strcat('No of Generations = ',num2str(length(time_chk_algo)));
    G4_Axes.XLabel.Color = [1 1 1];
    G4_Axes.YLabel.String = 'Algorithm Loop Time';
    G4_Axes.YLabel.Color = [1 1 1];

    %=====================================
    
%%