function Fitness = objective_function(robots_pos,robots_pos_targ,target_mat)
norbt=size(robots_pos);
notrg=size(robots_pos_targ);
num_robs = 1:norbt;
num_targ = 1:notrg;
num_targ = num_targ';
num_robs = num_robs';
% Check number of targets occupied
[~,ind] = ismember(robots_pos,robots_pos_targ,'rows');
valuee_targ = setdiff(num_targ,ind);

[~,ind] = ismember(robots_pos_targ,robots_pos,'rows');
valuee_rob = setdiff(num_robs,ind);

if length(valuee_targ) == 1
    Fitness = abs((robots_pos(valuee_rob,1)-robots_pos_targ(valuee_targ,1)))^2+abs((robots_pos(valuee_rob,2)-robots_pos_targ(valuee_targ,2)))^2+abs((robots_pos(valuee_rob,3)-robots_pos_targ(valuee_targ,3)))^2;
elseif length(valuee_targ) > 1
    for i=1:length(valuee_targ)
        value1 = valuee_targ(i);
        for j=1:length(valuee_targ)
            value2 = valuee_rob(j);
            lengths(j,i) = abs((robots_pos(value2,1)-robots_pos_targ(value1,1)))^2+abs((robots_pos(value2,2)-robots_pos_targ(value1,2)))^2+abs((robots_pos(value2,3)-robots_pos_targ(value1,3)))^2;
        end
    end
    slength = size(lengths);
    for chk = 1:slength(1)
        targ_del = find(lengths(chk,:)==min(lengths(chk,:))) ;
        rob_fit_val(chk)=lengths(chk,min(targ_del));
        lengths(:,min(targ_del))=Inf;
    end
    Fitness = sum(rob_fit_val);
    %Fitness1 =sqrt(rob_fit_val);
end
if ~exist('Fitness')
    Fitness = 0;
end
end