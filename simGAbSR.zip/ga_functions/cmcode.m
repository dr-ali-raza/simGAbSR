for i=1:4
    [robots_pos,robots_pos_center,m] = move_robot_x(mynw,robots_pos,10,-1)
end
for i=1:5
    [robots_pos,robots_pos_center,m] = move_robot_z(mynw,robots_pos,10,-1)
end