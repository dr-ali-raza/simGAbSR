function y=check_ga(x)
    y=x^2-1;
end